document.addEventListener('DOMContentLoaded', function() {
   
    fetch('noticias.json') //aqui hago el script para subir el archivo json en nuestra pagina web
        .then(response => response.json())
        .then(data => {
            const noticiasDiv = document.getElementById('lista-noticias');
            
           
            data.noticias.forEach(noticia => {
                const noticiaElement = document.createElement('div');
                noticiaElement.classList.add('noticia');

                noticiaElement.innerHTML = `
                    <h3>${noticia.titulo}</h3>
                    <p>${noticia.contenido}</p>
                    <small>${noticia.fecha}</small>
                `;

                noticiasDiv.appendChild(noticiaElement);
            });
        })
        .catch(error => console.error('Error al cargar las noticias:', error));
});