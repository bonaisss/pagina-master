document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('presupuesto-form');
    const totalDisplay = document.getElementById('presupuesto-total');

    form.addEventListener('input', function () {
        let total = 0;

        // obtengo el precio del muffin
        const producto = form.querySelector('#producto');
        const precioProducto = parseFloat(producto.options[producto.selectedIndex].dataset.precio);

        // obtengo el plazo
        const plazo = parseInt(form.querySelector('#plazo').value) || 0;

        // extras
        const extras = form.querySelectorAll('input[name="extras"]:checked');
        let precioExtras = 0;
        extras.forEach(extra => {
            precioExtras += parseFloat(extra.value);
        });

        // sumar extras y el producto
        total = precioProducto + precioExtras;

        // descuento si es mayor o igual a 30 dias
        if (plazo >= 30) {
            total *= 0.9; 
        }

        // mostrar total de la compra
        totalDisplay.textContent = `$${total.toFixed(2)}`;
    });
    const nombreInput = document.getElementById('nombre');
    const apellidoInput = document.getElementById('apellido');
    
    const telefonoInput = document.getElementById('telefono');
    const emailInput = document.getElementById('email');

    form.addEventListener('submit', function (e) {
        // Validación de solo letras/numero/email
        const soloLetras = /^[a-zA-ZÀ-ÿ\s]{1,40}$/;
        const soloNumeros = /^[9]{9}$/;
        const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

        if (!soloLetras.test(nombreInput.value)) {
            alert('El campo Nombre solo puede contener letras y debe tener un máximo de 15 caracteres.');
            e.preventDefault();
        }

        if (!soloLetras.test(apellidoInput.value)) {
            alert('El campo Apellido solo puede contener letras y debe tener un máximo de 40 caracteres.');
            e.preventDefault();
        }
        if (!soloNumeros.test(telefonoInput.value)) {
            alert('El campo Teléfono solo puede contener números y debe tener exactamente 9 dígitos.');
            e.preventDefault();
        }
        if (!emailRegex.test(emailInput.value)) {
            alert('Por favor, ingrese un correo electrónico válido.');
            e.preventDefault();
        }

      
    });
});