document.addEventListener("DOMContentLoaded", function () {
    // Coordenadas de la empresa (puedes cambiarlas)
    const empresaLat = 39.4699; // Latitud de ejemplo (Valencia)
    const empresaLon = -0.3763; // Longitud de ejemplo (Valencia)

    // Inicializar el mapa centrado en la empresa
    const map = L.map('map').setView([empresaLat, empresaLon], 13);

    // Cargar la capa de mapa desde OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    }).addTo(map);

    // Añadir un marcador para la ubicación de la empresa
    const empresaMarker = L.marker([empresaLat, empresaLon])
        .addTo(map)
        .bindPopup("Ubicación de la Empresa")
        .openPopup();

    // Intentar obtener la ubicación del usuario
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function (position) {
                const userLat = position.coords.latitude;
                const userLon = position.coords.longitude;

                // Añadir un marcador para la ubicación del usuario
                const userMarker = L.marker([userLat, userLon])
                    .addTo(map)
                    .bindPopup("Tu ubicación")
                    .openPopup();

                // Crear la ruta entre el usuario y la empresa usando leaflet-routing-machine
                L.Routing.control({
                    waypoints: [
                        L.latLng(userLat, userLon),  // Punto de partida (usuario)
                        L.latLng(empresaLat, empresaLon)  // Punto de llegada (empresa)
                    ],
                    routeWhileDragging: true,
                    lineOptions: {
                        styles: [{ color: 'blue', opacity: 0.7, weight: 5 }]
                    },
                    createMarker: function() { return null; } // Opcional: oculta los marcadores de ruta
                }).addTo(map);

                // Ajustar el zoom para mostrar ambos puntos y la ruta
                const bounds = L.latLngBounds([empresaLat, empresaLon], [userLat, userLon]);
                map.fitBounds(bounds);
            },
            function () {
                alert("No se pudo obtener tu ubicación.");
            }
        );
    } else {
        alert("La geolocalización no está disponible en tu navegador.");
    }
});